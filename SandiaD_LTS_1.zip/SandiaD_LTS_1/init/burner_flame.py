"""
Burner-stabilized flame
=======================

A burner-stabilized lean premixed hydrogen-oxygen flame at low pressure.

Requires: cantera >= 3.0

.. tags:: Python, combustion, 1D flow, premixed flame, saving output,
          multicomponent transport
"""

from pathlib import Path
import cantera as ct

p = ct.one_atm
tburner = 400
mdot = 0.1023412903
reactants = 'CH4:1, O2:3.518, N2:9.282'  # premixed gas composition
width = 0.3  # m
loglevel = 1  # amount of diagnostic output (0 to 5)

gas = ct.Solution('myCH4NH3.yaml')
gas.TPX = tburner, p, reactants

f = ct.BurnerFlame(gas, width=width)
f.burner.mdot = mdot
f.set_refine_criteria(ratio=2.0, slope=0.1, curve=0.1)
f.max_time_step_count = 1000
f.show()

f.transport_model = 'mixture-averaged'
f.solve(loglevel, auto=True)

if "native" in ct.hdf_support():
    output = Path() / "burner_flame.h5"
else:
    output = Path() / "burner_flame.yaml"
output.unlink(missing_ok=True)

f.save(output, name="mix", description="solution with mixture-averaged transport")

f.transport_model = 'mixture-averaged'
f.solve(loglevel)  # don't use 'auto' on subsequent solves
f.show()
f.save(output, name="multi", description="solution with multicomponent transport")

f.save('burner_flame.csv', basis="mass", overwrite=True)