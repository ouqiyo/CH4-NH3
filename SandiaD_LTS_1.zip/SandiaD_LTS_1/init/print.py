# !/usr/bin/python
# coding: utf8
# @Time    : 2021-11-26 20:36:39
# @Author  : Shijie Xu
# @Email   : shijie.xu@energy.lth.se
# @Software: OpenFOAM

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import shlex
import os
import subprocess

data = pd.read_csv('init.csv')
cols = ['N2', 'O2', 'CO2', 'H2O', 'OH', 'CO']
for col in cols:
	print(col, data[col].iloc[0])

